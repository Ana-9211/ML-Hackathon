"""Configuration loaded from environment; private evaluator assets stay on Laptop 1."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Settings:
    mode: str = "trained"  # 'trained' (actual evaluation) or 'demo' (synthetic test only)
    eval_dir: Path = ROOT / "private_evaluator"
    demo_dir: Path = ROOT / "demo_data"
    model_path: Path = ROOT / "artifacts" / "final_model.joblib"
    team_predictor: str = ""  # optional package.module:function loaded by Laptop 1
    log_path: Path = ROOT / "logs" / "requests.jsonl"
    origins: tuple[str, ...] = ("http://localhost:5500", "http://127.0.0.1:5500")
    max_points: int = 20000
    max_arcs: int = 200000

    @property
    def data_dir(self) -> Path:
        return self.demo_dir if self.mode == "demo" else self.eval_dir

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            mode=os.getenv("M4_MODE", "trained").strip().lower(),
            eval_dir=Path(os.getenv("M4_EVAL_DIR", str(ROOT / "private_evaluator"))).resolve(),
            demo_dir=Path(os.getenv("M4_DEMO_DIR", str(ROOT / "demo_data"))).resolve(),
            model_path=Path(os.getenv("M4_MODEL_PATH", str(ROOT / "artifacts" / "final_model.joblib"))).resolve(),
            team_predictor=os.getenv("M4_TEAM_PREDICTOR", "").strip(),
            log_path=Path(os.getenv("M4_LOG_PATH", str(ROOT / "logs" / "requests.jsonl"))).resolve(),
            origins=tuple(s.strip().rstrip("/") for s in os.getenv(
                "M4_ALLOWED_ORIGINS", "http://localhost:5500,http://127.0.0.1:5500"
            ).split(",") if s.strip()),
            max_points=int(os.getenv("M4_MAX_POINTS", "20000")),
            max_arcs=int(os.getenv("M4_MAX_ARCS", "200000")),
        )
