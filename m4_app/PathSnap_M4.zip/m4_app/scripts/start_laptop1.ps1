# From m4_app: powershell -ExecutionPolicy Bypass -File .\scripts\start_laptop1.ps1 -Mode trained
param([ValidateSet("trained", "demo")][string]$Mode = "trained")
$ErrorActionPreference = "Stop"
Set-Location (Resolve-Path (Join-Path $PSScriptRoot ".."))
$env:M4_MODE = $Mode
Write-Host "PathSnap API on Laptop 1: mode=$Mode, port=8000" -ForegroundColor Cyan
Write-Host "Use http://<LAPTOP1_IPV4>:8000 on Laptop 2. See README.md." -ForegroundColor Yellow
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --access-log
